const blogId = new URLSearchParams(window.location.search).get('id');


function change(id) {
    var stars = document.getElementsByClassName('rating-star');
    var rating = document.getElementById(id + '_hidden').value;
    
    for(var i = 0; i < stars.length; i++) {
        if(i < rating) {
            stars[i].src = 'IMG-TEST/fi-sr-star2.png';
        } else {
            stars[i].src = 'IMG-TEST/fi-rr-star.png';
        }
    }
    
    document.getElementById('ratingValue').value = rating;
}

async function sendComment() {
    const blogId = new URLSearchParams(window.location.search).get('id');
    const comment = document.getElementById('comment').value;

    try {
        const response = await fetch(`/api/blogs/${blogId}/comments`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: comment })
        });

        const data = await response.json();
        document.getElementById('comment').value = '';
        loadComments(); // Обновляем список комментариев
    } catch (error) {
        console.error('Ошибка при отправке комментария:', error);
    }
}

async function loadComments() {
    const blogId = new URLSearchParams(window.location.search).get('id');

    try {
        const res = await fetch(`/api/blogs/${blogId}/comments`);
        const comments = await res.json();
        const container = document.getElementById('comments');
        container.innerHTML = comments.map(c => `<p>${c.text}</p>`).join('');
    } catch (error) {
        console.error('Ошибка при загрузке комментариев:', error);
    }
}

async function fetchAverageRating() {
    const blogId = new URLSearchParams(window.location.search).get('id');

    try {
        const response = await fetch(`/api/blogs/${blogId}/average_rating`);
        const data = await response.json();
        const average = isNaN(data.average_rating) ? 0.0 : data.average_rating;
        document.getElementById('averageRating').innerText = average.toFixed(1);
    } catch (error) {
        console.error('Ошибка загрузки среднего рейтинга:', error);
    }
}

// Загружаем средний рейтинг при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    fetchAverageRating();
    loadComments();
});

async function saveRating() {
    const rating = document.getElementById('ratingValue').value;
    const blogId = new URLSearchParams(window.location.search).get('id');

    try {
        const response = await fetch(`/api/blogs/${blogId}/ratings`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ rating })
        });

        const data = await response.json();
        alert('Спасибо за ваш отзыв!');
        fetchAverageRating();
    } catch (error) {
        console.error('Ошибка при сохранении рейтинга:', error);
        alert('Ошибка при сохранении рейтинга');
    }
}
